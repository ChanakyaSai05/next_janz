import React, { useState } from "react";
import Head from "next/head";
import Image from "next/image";
import Slider from "react-slick";
import { Inter } from "@next/font/google";
import styles from "../styles/Home.module.css";
import { Container, Nav, Tab, Col, Row, Dropdown } from "react-bootstrap";
import Headerlanding from "../components/headerlanding";
import Footer from "../components/footer";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import product from "../public/images/product.svg";
import cardImg1 from "../public/images/card-img1.svg";
import cardImg2 from "../public/images/card-img2.svg";
import cardImg3 from "../public/images/card-img3.svg";
import cardImg4 from "../public/images/card-img4.svg";
import airminiImg from "../public/images/air-mini.svg";
import fullmask2 from "../public/images/fullmask2.svg";
import { useRouter } from "next/router";

const inter = Inter({ subsets: ["latin"] });

export default function Product() {
  const router = useRouter();
  let settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    initialSlide: 0,
    autoplay: true,
    autoplaySpeed: 2000,
    pauseOnHover: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          initialSlide: 1,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  // const [chooseMask, setChooseMask] = useState(true);
  const [stateObj, setstateObj] = useState({
    first: true,
    second: false,
    third: false,
  });

  const [editCancel, setEditCancel] = useState(false);

  return (
    <>
      <Headerlanding></Headerlanding>
      <div className="">
        <div className="container">
          <div className="row pt-4">
            <div className="col-sm-12 col-lg-3 order-lg-1">
              <div className="incart-box">
                <h4
                  className="accordion-button"
                  data-bs-toggle="collapse"
                  role="button"
                  data-bs-target="#items"
                >
                  In Cart
                </h4>
                <div className="collapse show" id="items">
                  <a href="#" className="d-block my-3">
                    <p>AirMini Autoset</p>
                    <Image
                      width={160}
                      height={120}
                      src={airminiImg}
                      alt="..."
                    />
                  </a>
                  <a href="#" className="d-block my-3">
                    <p>AirTouch F20 Replacement Frame System</p>
                    <Image width={160} height={120} src={fullmask2} alt="..." />
                  </a>
                  <button
                    type="button"
                    className="btn btn-primary w-100"
                    onClick={() => router.push("/cart_items")}
                  >
                    Proceed to Cart
                  </button>
                </div>
              </div>
            </div>
            <div className="col-sm-12 col-lg-9">
              <h4 className="py-4">
                Other Accessories bought with AirMini Autoset{" "}
              </h4>
              <div className="d-flex pb-5">
                <div className="me-3 title-img card-shadow">
                  <Image width={120} height={120} src={cardImg2} alt="..." />
                </div>
                <div className="">
                  <h4 className="pb-2">Title 1</h4>
                  <p>
                    The Spectra S1 Plus Electric Breast Pump is the perfect
                    solution for any new mom who needs to pump their breastmilk.
                    This award-winning, dual voltage pump was designed with
                    convenience, comfort and efficiency in mind. Featuring an
                    ultra
                  </p>
                  <button
                    type="button"
                    className="btn btn-outline-primary px-3"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
              <div className="d-flex pb-5">
                <div className="me-3 title-img card-shadow">
                  <Image width={120} height={120} src={cardImg2} alt="..." />
                </div>
                <div className="">
                  <h4 className="pb-2">Title 1</h4>
                  <p>
                    The Spectra S1 Plus Electric Breast Pump is the perfect
                    solution for any new mom who needs to pump their breastmilk.
                    This award-winning, dual voltage pump was designed with
                    convenience, comfort and efficiency in mind. Featuring an
                    ultra
                  </p>
                  <button
                    type="button"
                    className="btn btn-outline-primary px-3"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
              <div className="d-flex pb-5">
                <div className="me-3 title-img card-shadow">
                  <Image width={120} height={120} src={cardImg2} alt="..." />
                </div>
                <div className="">
                  <h4 className="pb-2">Title 1</h4>
                  <p>
                    The Spectra S1 Plus Electric Breast Pump is the perfect
                    solution for any new mom who needs to pump their breastmilk.
                    This award-winning, dual voltage pump was designed with
                    convenience, comfort and efficiency in mind. Featuring an
                    ultra
                  </p>
                  <button
                    type="button"
                    className="btn btn-outline-primary px-3"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Slider 1*/}
      <div className="product-slider-box pb-5">
        <div className="container py-5">
          <div className="row pb-5">
            <div className="col-12">
              <h3>Recently Viewed</h3>
            </div>
          </div>
          <div className="row">
            <div className="12">
              <Slider {...settings}>
                <div className="card">
                  <div className="card-bodys">
                    <div className="d-flex justify-content-between">
                      <div className="like-down-box">
                        <svg className="icon">
                          <use href="#icon_like-dull"></use>
                        </svg>
                      </div>
                      <div className="download-box">
                        <svg className="icon">
                          <use href="#icon_loader-dull"></use>
                        </svg>
                      </div>
                    </div>
                    <div className="d-flex my-2 py-2 justify-content-center">
                      <div className="card-img">
                        <Image
                          width={180}
                          height={180}
                          src={cardImg1}
                          alt="..."
                        />
                      </div>
                    </div>
                    <p className="card-text">5 OZ Breast Milk Bottle Set</p>
                    <span className="badge text-bg-primary p-2 px-3 me-2">
                      4.2 &#9733;
                    </span>
                    <span>(166)</span>
                  </div>
                </div>
                <div className="card">
                  <div className="card-bodys">
                    <div className="d-flex justify-content-between">
                      <div className="like-down-box">
                        <svg className="icon">
                          <use href="#icon_like"></use>
                        </svg>
                      </div>
                      <div className="download-box">
                        <svg className="icon">
                          <use href="#icon_loader"></use>
                        </svg>
                        <span>1</span>
                      </div>
                    </div>
                    <div className="d-flex my-2 py-2 justify-content-center">
                      <div className="card-img">
                        <Image
                          width={159}
                          height={160}
                          src={cardImg2}
                          alt="..."
                        />
                      </div>
                    </div>
                    <p className="card-text">
                      Spectra S1 Plus Electric Breast Pump Dual Voltage
                    </p>
                    <span className="badge text-bg-primary p-2 px-3 me-2">
                      4.1 &#9733;
                    </span>
                    <span>(176)</span>
                  </div>
                </div>
                <div className="card">
                  <div className="card-bodys">
                    <div className="d-flex justify-content-between">
                      <div className="like-down-box">
                        <svg className="icon">
                          <use href="#icon_like-dull"></use>
                        </svg>
                      </div>
                      <div className="download-box">
                        <svg className="icon">
                          <use href="#icon_loader-dull"></use>
                        </svg>
                        {/* <span>1</span> */}
                      </div>
                    </div>
                    <div className="d-flex my-2 py-2 justify-content-center">
                      <div className="card-img">
                        <Image
                          width={180}
                          height={180}
                          src={cardImg3}
                          alt="..."
                        />
                      </div>
                    </div>
                    <p className="card-text">Lansinoh Resupply Kit</p>
                    <span className="badge text-bg-primary p-2 px-3 me-2">
                      4.4 &#9733;
                    </span>
                    <span>(200)</span>
                  </div>
                </div>
                <div className="card">
                  <div className="card-bodys">
                    <div className="d-flex justify-content-between">
                      <div className="like-down-box">
                        <svg className="icon">
                          <use href="#icon_like-dull"></use>
                        </svg>
                      </div>
                      <div className="download-box">
                        <svg className="icon">
                          <use href="#icon_loader-dull"></use>
                        </svg>
                        {/* <span>1</span> */}
                      </div>
                    </div>
                    <div className="d-flex my-2 py-2 justify-content-center">
                      <div className="card-img">
                        <Image
                          width={125}
                          height={160}
                          src={cardImg4}
                          alt="..."
                        />
                      </div>
                    </div>
                    <p className="card-text">Bambo Nature Love Balm</p>
                    <span className="badge text-bg-primary p-2 px-3 me-2">
                      4.0 &#9733;
                    </span>
                    <span>(123)</span>
                  </div>
                </div>
                <div className="card">
                  <div className="card-bodys">
                    <div className="d-flex justify-content-between">
                      <div className="like-down-box">
                        <svg className="icon">
                          <use href="#icon_like"></use>
                        </svg>
                      </div>
                      <div className="download-box">
                        <svg className="icon">
                          <use href="#icon_loader"></use>
                        </svg>
                        <span>1</span>
                      </div>
                    </div>
                    <div className="d-flex my-2 py-2 justify-content-center">
                      <div className="card-img">
                        <Image
                          width={159}
                          height={160}
                          src={cardImg2}
                          alt="..."
                        />
                      </div>
                    </div>
                    <p className="card-text">
                      Spectra S1 Plus Electric Breast Pump Dual Voltage
                    </p>
                    <span className="badge text-bg-primary p-2 px-3 me-2">
                      4.1 &#9733;
                    </span>
                    <span>(176)</span>
                  </div>
                </div>
              </Slider>
            </div>
          </div>
        </div>
      </div>
      {/* Slider End */}
      <Footer></Footer>
    </>
  );
}
