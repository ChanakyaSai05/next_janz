import React from "react";

function CategoryMainPage() {
  return <div>CategoryMainPage</div>;
}

export default CategoryMainPage;
