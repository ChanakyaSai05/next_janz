import React from "react";

function insuranceId() {
  return <div>insuranceId</div>;
}

export default insuranceId;
