import React from "react";

function index_cat() {
  return <div>index_cat</div>;
}

export default index_cat;
