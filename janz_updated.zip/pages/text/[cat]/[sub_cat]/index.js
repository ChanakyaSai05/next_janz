import React from "react";

function index_subCat() {
  return <div>index_subCat</div>;
}

export default index_subCat;
