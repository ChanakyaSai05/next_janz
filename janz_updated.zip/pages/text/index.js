import React from "react";

function index() {
  return <div>index_root</div>;
}

export default index;
