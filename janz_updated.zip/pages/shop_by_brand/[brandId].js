import React from "react";

function brandId() {
  return <div>brandId</div>;
}

export default brandId;
